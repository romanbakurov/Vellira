import type { ReactNode } from 'react';
import React from 'react';

export interface DropdownTriggerProps {
  children?: ReactNode;
  isOpen: boolean;
  disabled?: boolean;
  label?: string;
  icon?: ReactNode;
  rotateAngle?: number;
  arrowIcon?: ReactNode;
  onClick?: () => void;
  onKeyDown?: React.KeyboardEventHandler<HTMLButtonElement>;
  'aria-expanded': boolean;
  'aria-haspopup'?: boolean | 'menu';
  'aria-controls'?: string;
  'aria-label'?: string;
  className?: string;
}
