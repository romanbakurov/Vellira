export interface InputProps {
  value?: string;
  placeholder?: string;
  disabled?: boolean;
  error?: boolean;
}
